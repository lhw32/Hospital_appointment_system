-- 시퀀스 생성 (Sequence Generation)

DROP SEQUENCE PT_ID_SEQ;
DROP SEQUENCE DR_ID_SEQ;
DROP SEQUENCE SCH_ID_SEQ;
DROP SEQUENCE APPT_ID_SEQ;
DROP SEQUENCE TREAT_ID_SEQ;

CREATE SEQUENCE PT_ID_SEQ START WITH 1000 INCREMENT BY 1;
CREATE SEQUENCE DR_ID_SEQ START WITH 200 INCREMENT BY 1;
CREATE SEQUENCE SCH_ID_SEQ START WITH 3000 INCREMENT BY 1;
CREATE SEQUENCE APPT_ID_SEQ START WITH 4000 INCREMENT BY 1;
CREATE SEQUENCE TREAT_ID_SEQ START WITH 5000 INCREMENT BY 1;

-- 테이블 생성 (Table Creation)

-- 진료과 (DEPARTMENT)
CREATE TABLE DEPARTMENT (
    DEPT_CODE   CHAR(3)         PRIMARY KEY,
    DEPT_NAME   VARCHAR2(50)    NOT NULL UNIQUE
);

-- 환자 (PATIENT)
CREATE TABLE PATIENT (
    PT_ID       NUMBER(10)      PRIMARY KEY,
    PT_NAME     VARCHAR2(50)    NOT NULL,
    PT_SSN      CHAR(14)        NOT NULL UNIQUE, -- 주민등록번호
    PT_PHONE    VARCHAR2(20),
    PT_ADDRESS  VARCHAR2(200),
    PT_REG_DATE DATE            DEFAULT SYSDATE NOT NULL
);

-- 의사 (DOCTOR)
CREATE TABLE DOCTOR (
    DR_ID           NUMBER(5)       PRIMARY KEY,
    DR_NAME         VARCHAR2(50)    NOT NULL,
    DEPT_CODE       CHAR(3)         NOT NULL,
    DR_LICENSE_NO   CHAR(10)        NOT NULL UNIQUE,
    DR_PHONE        VARCHAR2(20),
    DR_EMAIL        VARCHAR2(100),
    CONSTRAINT FK_DOCTOR_DEPT FOREIGN KEY (DEPT_CODE) REFERENCES DEPARTMENT(DEPT_CODE)
);

-- 의사 스케줄 (SCHEDULE)
CREATE TABLE SCHEDULE (
    SCH_ID          NUMBER(10)      PRIMARY KEY,
    DR_ID           NUMBER(5)       NOT NULL,
    SCH_DATE        DATE            NOT NULL,
    SCH_START_TIME  CHAR(5)         NOT NULL, -- 'HH24:MI'
    SCH_END_TIME    CHAR(5)         NOT NULL, -- 'HH24:MI'
    CONSTRAINT UK_SCHEDULE UNIQUE (DR_ID, SCH_DATE),
    CONSTRAINT FK_SCHEDULE_DR FOREIGN KEY (DR_ID) REFERENCES DOCTOR(DR_ID)
);

-- 진료 예약 (APPOINTMENT)
CREATE TABLE APPOINTMENT (
    APPT_ID         NUMBER(10)      PRIMARY KEY,
    PT_ID           NUMBER(10)      NOT NULL,
    DR_ID           NUMBER(5)       NOT NULL,
    DR_NAME         VARCHAR2(50)    NOT NULL,
    APPT_DATETIME   DATE            NOT NULL,
    APPT_STATUS     VARCHAR2(10)    NOT NULL, 
    APPT_REASON     VARCHAR2(500),
    CONSTRAINT UK_APPT_TIME UNIQUE (DR_ID, APPT_DATETIME),
    CONSTRAINT FK_APPT_PT FOREIGN KEY (PT_ID) REFERENCES PATIENT(PT_ID),
    CONSTRAINT FK_APPT_DR FOREIGN KEY (DR_ID) REFERENCES DOCTOR(DR_ID)
);

-- 진료 기록 (TREATMENT)
CREATE TABLE TREATMENT (
    TREAT_ID        NUMBER(10)      PRIMARY KEY,
    APPT_ID         NUMBER(10)      NOT NULL UNIQUE,
    PT_ID           NUMBER(10)      NOT NULL,
    DR_ID           NUMBER(5)       NOT NULL,
    TREAT_DATE      DATE            DEFAULT SYSDATE NOT NULL,
    TREAT_CONTENT   VARCHAR2(4000),
    TREAT_COST      NUMBER(10)      DEFAULT 0 NOT NULL,
    CONSTRAINT FK_TREAT_APPT FOREIGN KEY (APPT_ID) REFERENCES APPOINTMENT(APPT_ID),
    CONSTRAINT FK_TREAT_PT FOREIGN KEY (PT_ID) REFERENCES PATIENT(PT_ID),
    CONSTRAINT FK_TREAT_DR FOREIGN KEY (DR_ID) REFERENCES DOCTOR(DR_ID)
);

-- 3. 데이터 삽입 (Sample Data Insertion)

-- 진료과
INSERT INTO DEPARTMENT (DEPT_CODE, DEPT_NAME) VALUES ('INT', '내과');
INSERT INTO DEPARTMENT (DEPT_CODE, DEPT_NAME) VALUES ('SUR', '외과');
INSERT INTO DEPARTMENT (DEPT_CODE, DEPT_NAME) VALUES ('PED', '소아청소년과');
COMMIT;

-- 환자
INSERT INTO PATIENT (PT_ID, PT_NAME, PT_SSN, PT_PHONE, PT_ADDRESS) VALUES (PT_ID_SEQ.NEXTVAL, '김철수', '900101-1000000', '010-1234-5678', '서울시 강남구');
INSERT INTO PATIENT (PT_ID, PT_NAME, PT_SSN, PT_PHONE, PT_ADDRESS) VALUES (PT_ID_SEQ.NEXTVAL, '이영희', '950505-2000000', '010-9876-5432', '경기도 성남시');
COMMIT;

-- 의사
INSERT INTO DOCTOR (DR_ID, DR_NAME, DEPT_CODE, DR_LICENSE_NO, DR_EMAIL) VALUES (DR_ID_SEQ.NEXTVAL, '박민준', 'INT', 'MD10000001', 'pmj@hospital.com'); -- DR_ID: 200
INSERT INTO DOCTOR (DR_ID, DR_NAME, DEPT_CODE, DR_LICENSE_NO, DR_EMAIL) VALUES (DR_ID_SEQ.NEXTVAL, '최지영', 'SUR', 'MD10000002', 'cjy@hospital.com'); -- DR_ID: 201
COMMIT;

-- 스케줄 (박민준 의사 - 내과)
-- 2025년 12월 10일 스케줄
INSERT INTO SCHEDULE (SCH_ID, DR_ID, SCH_DATE, SCH_START_TIME, SCH_END_TIME) VALUES (SCH_ID_SEQ.NEXTVAL, 200, DATE '2025-12-10', '09:00', '18:00');
COMMIT;

-- PL/SQL 구현 (Stored Procedure)

CREATE OR REPLACE PROCEDURE PROC_APPOINTMENT_REGISTER (
    p_pt_id         IN NUMBER,
    p_dr_id         IN NUMBER,
    p_appt_datetime IN DATE,
    p_appt_reason   IN VARCHAR2,
    p_result_msg    OUT VARCHAR2
)
IS
    v_dr_name       DOCTOR.DR_NAME%TYPE;
    v_is_scheduled  NUMBER := 0;
    v_is_duplicate  NUMBER := 0;
BEGIN
    SELECT DR_NAME INTO v_dr_name FROM DOCTOR WHERE DR_ID = p_dr_id;

    SELECT COUNT(*)
    INTO v_is_scheduled
    FROM SCHEDULE
    WHERE DR_ID = p_dr_id
      AND TRUNC(SCH_DATE) = TRUNC(p_appt_datetime)
      AND TO_CHAR(p_appt_datetime, 'HH24:MI') BETWEEN SCH_START_TIME AND SCH_END_TIME;

    IF v_is_scheduled = 0 THEN
        p_result_msg := '예약 실패: 선택하신 날짜/시간에 의사님의 근무 스케줄이 없습니다.';
        RETURN;
    END IF;

	SELECT COUNT(*)
    INTO v_is_duplicate
    FROM APPOINTMENT
    WHERE PT_ID = p_pt_id
      AND DR_ID = p_dr_id
      AND APPT_DATETIME = p_appt_datetime
      AND APPT_STATUS != '취소';


    IF v_is_duplicate > 0 THEN
        p_result_msg := '예약 실패: 이미 해당 시간대에 동일한 예약이 존재합니다.';
        RETURN;
    END IF;

    INSERT INTO APPOINTMENT (APPT_ID, PT_ID, DR_ID, DR_NAME, APPT_DATETIME, APPT_STATUS, APPT_REASON)
    VALUES (APPT_ID_SEQ.NEXTVAL, p_pt_id, p_dr_id, v_dr_name, p_appt_datetime, '대기', p_appt_reason);
    COMMIT;
    p_result_msg := '예약 성공: 예약이 정상적으로 등록되었습니다.';

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        p_result_msg := '예약 실패: 환자 또는 의사 정보가 유효하지 않습니다.';
    WHEN OTHERS THEN
        ROLLBACK;
        p_result_msg := '예약 실패: 데이터베이스 오류가 발생했습니다. ' || SQLERRM;
END;
/

-- PL/SQL 테스트 (Test Execution)

SET SERVEROUTPUT ON;
DECLARE
    v_result_msg VARCHAR2(200);
    v_appt_time DATE := TO_DATE('2025-12-10 10:30', 'YYYY-MM-DD HH24:MI');
BEGIN
    -- 성공 케이스: 환자 김철수(1000)가 의사 박민준(200)에게 12월 10일 10:30에 예약
    DBMS_OUTPUT.PUT_LINE('--- 테스트 1: 성공 케이스 ---');
    PROC_APPOINTMENT_REGISTER(
        p_pt_id => 1000,
        p_dr_id => 200,
        p_appt_datetime => v_appt_time,
        p_appt_reason => '감기 증상',
        p_result_msg => v_result_msg
    );
    DBMS_OUTPUT.PUT_LINE(v_result_msg);

    -- 실패 케이스: 중복 예약 시도
    DBMS_OUTPUT.PUT_LINE('--- 테스트 2: 중복 예약 실패 케이스 ---');
    PROC_APPOINTMENT_REGISTER(
        p_pt_id => 1000,
        p_dr_id => 200,
        p_appt_datetime => v_appt_time, -- 동일 시간
        p_appt_reason => '재예약 시도',
        p_result_msg => v_result_msg
    );
    DBMS_OUTPUT.PUT_LINE(v_result_msg);

    -- 실패 케이스: 의사 근무 시간 외 예약 시도 (08:30)
    DBMS_OUTPUT.PUT_LINE('--- 테스트 3: 스케줄 없음 실패 케이스 ---');
    PROC_APPOINTMENT_REGISTER(
        p_pt_id => 1001,
        p_dr_id => 200,
        p_appt_datetime => TO_DATE('2025-12-10 08:30', 'YYYY-MM-DD HH24:MI'),
        p_appt_reason => '오픈 전 예약',
        p_result_msg => v_result_msg
    );
    DBMS_OUTPUT.PUT_LINE(v_result_msg);

END;
/